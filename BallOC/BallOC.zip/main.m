//
//  main.m
//  BallOC
//
//  Created by gwh on 2019/12/9.
//  Copyright 2019 gwh. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char * argv[]) {
     @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, @"CC_AppDelegate");
    }
}
