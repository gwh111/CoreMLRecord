//
//  ViewController.swift
//  Ball
//
//  Created by gwh on 2019/12/6.
//  Copyright © 2019 gwh. All rights reserved.
//

import UIKit
import RealityKit

class PointVC: UIViewController {
    
//    @IBOutlet var arView: ARView!
    
    let playground = DrawPlayground.init()
    var arrowConnectLayer: ArrowConnectLayer!
    
    var drawTopCourtView: DrawTopCourtView!
    
    var moveMutArr = NSMutableArray.init()
    var move_now: CALayer!
    var move_now_tag = 0
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        ccs.setDeviceOrientation(UIDeviceOrientation.landscapeRight)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        ccs.setDeviceOrientation(UIDeviceOrientation.portrait)
    }
    
    func shouldAutorotate() -> Bool {
        return false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.white
        
        var height = UIScreen.main.bounds.size.height
        var width = UIScreen.main.bounds.size.width
        if height > width {
            height = width + height
            width = height - width
            height = height - width
        }
        
        let imageView = UIImageView.init()
        imageView.frame = CGRect(x: 0, y: 0, width: width, height: height)
        imageView.image = UIImage.init(named: "playground")
        self.view.addSubview(imageView)
        
        let p_topLeft = CGPoint(x: 400, y: 205)
        let p_topRight = CGPoint(x: 600, y: 225)
        let p_bottomLeft = CGPoint(x: 135, y: 225)
        let p_bottomRight = CGPoint(x: 265, y: 265)
        
        // 俯视图固定点位
        let t_topLeft = CGPoint(x: 88, y: 5)
        let t_topRight = CGPoint(x: 163, y: 5)
        let t_bottomRight = CGPoint(x: 163, y: 85)
        let t_bottomLeft = CGPoint(x: 88, y: 85)
        let fixPoints:NSArray = [t_topLeft, t_topRight, t_bottomRight, t_bottomLeft]
        
        playground.setPoints(topLeft: p_topLeft, topRight: p_topRight, bottomLeft: p_bottomLeft, bottomRight: p_bottomRight)
        playground.frame = imageView.frame
        playground.backgroundColor = UIColor.clear
        self.view.addSubview(playground)
        playground.addPoint(point: CGPoint(x: 125, y: 235))
        playground.addPoint(point: CGPoint(x: 185, y: 235))
        playground.addPoint(point: CGPoint(x: 285, y: 200))
        playground.addPoint(point: CGPoint(x: 485, y: 305))
        
        let topCourtFrame = CGRect(x: width - 290, y: 0, width: 250, height: 150)
        
        let background:CC_ImageView = ccs.imageView()
        background.frame = topCourtFrame
        background.image = UIImage.init(named: "basketball_court")
        self.view.addSubview(background)
        
        drawTopCourtView = DrawTopCourtView.init(frame: topCourtFrame)
        drawTopCourtView.fixPointsPoint = fixPoints
        self.view.addSubview(drawTopCourtView)
        
        let convert = PointConvert.init()
        convert.setPlaygroundPoints(topLeft: CGPoint(x: p_topLeft.x, y: height - p_topLeft.y), topRight: CGPoint(x: p_topRight.x, y: height - p_topRight.y), bottomLeft: CGPoint(x: p_bottomLeft.x, y: height - p_bottomLeft.y), bottomRight: CGPoint(x: p_bottomRight.x, y: height - p_bottomRight.y))
        convert.setTopViewPoints(topLeft: CGPoint(x: t_topLeft.x, y: 200 - t_topLeft.y), topRight: CGPoint(x: t_topRight.x, y: 200 - t_topRight.y), bottomLeft: CGPoint(x: t_bottomLeft.x, y: 200 - t_bottomLeft.y), bottomRight: CGPoint(x: t_bottomRight.x, y: 200 - t_bottomRight.y))
        
        let point = convert.convertPoint(point: CGPoint(x: 125, y: height - 235))
        drawTopCourtView.addPoint(point: CGPoint(x: point.x, y: point.y))
        
        let point2 = convert.convertPoint(point: CGPoint(x: 185, y: height - 235))
        drawTopCourtView.addPoint(point: CGPoint(x: point2.x, y: point2.y))
        
        let point3 = convert.convertPoint(point: CGPoint(x: 285, y: height - 200))
        drawTopCourtView.addPoint(point: CGPoint(x: point3.x, y: point3.y))
        
        let point4 = convert.convertPoint(point: CGPoint(x: 485, y: height - 305))
        drawTopCourtView.addPoint(point: CGPoint(x: point4.x, y: point4.y))
        
        
        let shootView = DrawShootView.init()
        shootView.frame = imageView.frame
        shootView.backgroundColor = UIColor.clear
        self.view.addSubview(shootView)
        
        shootView.addShoot(fromPoint: CGPoint(x: 200, y: 100), topPoint: CGPoint(x: 350, y: 20))
        playground.addPoint(point: CGPoint(x: 200, y: 100))
        playground.addPoint(point: CGPoint(x: 350, y: 20))
        
        shootView.addShoot(fromPoint: CGPoint(x: 600, y: 120), topPoint: CGPoint(x: 550, y: 20))
        playground.addPoint(point: CGPoint(x: 600, y: 120))
        playground.addPoint(point: CGPoint(x: 550, y: 20))
        
        let backButton = ccs.button()!
        backButton.frame = CGRect(x: 30, y: 30, width: 50, height: 50)
        backButton.backgroundColor = UIColor.black
        backButton.setTitle("后退", for: .normal)
        backButton.alpha = 0.4
        backButton.layer.cornerRadius = 25
        self.view.addSubview(backButton)
        backButton.cc_addTappedOnceDelay(0.1) { (button) in
            ccs.popViewController()
        }
        
        arrowConnectLayer = ArrowConnectLayer()
        arrowConnectLayer.frame = playground.frame
        playground.layer.addSublayer(arrowConnectLayer)
        
        let xs = [50,150,200,0]
        let ys = [0,0,50,50]
        
        for i in 0..<4 {
            let point:ArrowLayer = ArrowLayer()
            point.frame = CGRect(x: 300 + xs[i], y: 200 + ys[i], width: 25, height: 25)
            point.setNeedsDisplay()
            playground.layer.addSublayer(point)
            
            arrowConnectLayer.points[i] = CGPoint(x: point.position.x, y: point.position.y + 10)
            
            moveMutArr.add(point)
        }
        arrowConnectLayer.setNeedsDisplay()
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {

        let point:CGPoint = (touches.first?.location(in: self.view))!
        for i in 0..<4 {
            
            let view:CALayer = moveMutArr[i] as! CALayer
            
            if view.frame.contains(point) {
                move_now = view
                move_now_tag = i
                drawTopCourtView.highlight(index: i)
            }
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {

        let point:CGPoint = (touches.first?.location(in: self.view))!
        move_now?.position = point
        
        if (move_now != nil) {

            arrowConnectLayer.points[move_now_tag] = CGPoint(x: point.x, y: point.y + 10)
            arrowConnectLayer.setNeedsDisplay()
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        move_now = nil
    }
}
