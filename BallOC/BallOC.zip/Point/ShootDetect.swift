//
//  ShootDetect.swift
//  Ball
//
//  Created by gwh on 2019/12/9.
//  Copyright © 2019 gwh. All rights reserved.
//

import UIKit

class ShootDetect: NSObject {
    
    var shootCount = 0
    var shootInCount = 0
    
    enum State {
        case playBall
        case shoot
        case shootEnd
    }
    
    var currentState = State.playBall

    func update(bodyPoint:CGPoint, ballPoint:CGPoint, boardPoint:CGPoint) -> Void {
        
        
        
    }
}
