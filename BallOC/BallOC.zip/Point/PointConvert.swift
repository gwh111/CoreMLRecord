//
//  PointConvert.swift
//  Ball
//
//  Created by gwh on 2019/12/6.
//  Copyright © 2019 gwh. All rights reserved.
//

import UIKit

class PointConvert: NSObject {
    
    var playgroundPoints = NSArray.init()
    var topViewPoints = NSArray.init()
    
    var k1:Float = 0
    var b1:Float = 0
    
    var k2:Float = 0
    var b2:Float = 0
    
    var k3:Float = 0
    var b3:Float = 0
    
    var k4:Float = 0
    var b4:Float = 0
    
    func setPlaygroundPoints(topLeft:CGPoint, topRight:CGPoint, bottomLeft:CGPoint, bottomRight:CGPoint) -> Void {
        
        playgroundPoints = [topLeft, topRight, bottomLeft, bottomRight];
        
        let y1 = Float(topLeft.y)
        let x1 = Float(topLeft.x)
        let y2 = Float(topRight.y)
        let x2 = Float(topRight.x)
        var k:Float
        var b:Float
        k = (y1 - y2)/(x1 - x2)
        b = y1 - k * x1
        k1 = k
        b1 = b
        print("%f %f",k1,b1)
    
        let y1_b = Float(bottomLeft.y)
        let x1_b = Float(bottomLeft.x)
        let y2_b = Float(bottomRight.y)
        let x2_b = Float(bottomRight.x)
        var k_b:Float
        var b_b:Float
        k_b = (y1_b - y2_b)/(x1_b - x2_b)
        b_b = y1_b - k_b * x1_b
        k2 = k_b
        b2 = b_b
        print("%f %f",k2,b2)
        
        let y1_l = Float(topLeft.y)
        let x1_l = Float(topLeft.x)
        let y2_l = Float(bottomLeft.y)
        let x2_l = Float(bottomLeft.x)
        var k_l:Float
        var b_l:Float
        k_l = (y1_l - y2_l)/(x1_l - x2_l)
        b_l = y1_l - k_l * x1_l
        k3 = k_l
        b3 = b_l
        print("%f %f",k3,b3)
        
        let y1_r = Float(topRight.y)
        let x1_r = Float(topRight.x)
        let y2_r = Float(bottomRight.y)
        let x2_r = Float(bottomRight.x)
        var k_r:Float
        var b_r:Float
        k_r = (y1_r - y2_r)/(x1_r - x2_r)
        b_r = y1_r - k_r * x1_r
        k4 = k_r
        b4 = b_r
        print("%f %f",k4,b4)
    }
    
    func setTopViewPoints(topLeft:CGPoint, topRight:CGPoint, bottomLeft:CGPoint, bottomRight:CGPoint) -> Void {
        
        topViewPoints = [topLeft, topRight, bottomLeft, bottomRight];
        
    }
    
    func convertPoint(point:CGPoint) -> CGPoint {
        
        let height = UIScreen.main.bounds.size.height
        let y = Float(point.y)
        let x = Float(point.x)
        
        var opx = Float(0)
        var opy = Float(0)
        
        var mulx = Float(1)
        var muly = Float(1)
        
        var typex = Float(0)
        var typey = Float(0)
        
        let k = 1/k1
        let b = y - x * k
        var xx = Float(0)
        var yy = Float(0)
        yy = xx * k + b
        yy = xx * k1 + b1
        xx = (b1 - b) / (k - k1)
        yy = xx * k1 + b1
        let y2 = (yy - y) * fabsf(yy - y)
        let x2 = (xx - x) * fabsf(xx - x)
        let dis = sqrt(fabsf(y2 + x2))
        print(y2,x2,dis)
        
        let k_b = 1/k2
        let b_b = y - x * k_b
        var xx_b = Float(0)
        var yy_b = Float(0)
        yy_b = xx_b * k_b + b_b
        yy_b = xx_b * k2 + b2
        xx_b = (b2 - b_b) / (k_b - k2)
        yy_b = xx_b * k2 + b2
        let y2_b = (yy_b - y) * fabsf(yy_b - y)
        let x2_b = (xx_b - x) * fabsf(xx_b - x)
        let dis_b = sqrt(fabsf(y2_b + x2_b))
        print(y2_b,x2_b,dis_b)
        
        if fabsf(y2 + y2_b) == fabsf(y2) + fabsf(y2_b) {
            opy = Float(1)
            if y2 < 0 && y2_b < 0 {
                opy = Float(0)
                muly = -Float(1)
                typey = -Float(1)
            }
            if y2 > 0 && y2_b > 0 {
                typey = Float(1)
            }
        }
        
        let k_l = 1/k3
        let b_l = y - x * k_l
        var xx_l = Float(0)
        var yy_l = Float(0)
        yy_l = xx_l * k_l + b_l
        yy_l = xx_l * k3 + b3
        xx_l = (b3 - b_l) / (k_l - k3)
        yy_l = xx_l * k3 + b3
        let y2_l = (yy_l - y) * fabsf(yy_l - y)
        let x2_l = (xx_l - x) * fabsf(xx_l - x)
        let dis_l = sqrt(fabsf(y2_l + x2_l))
        print(y2_l,x2_l,dis_l)
        
        let k_r = 1/k4
        let b_r = y - x * k_r
        var xx_r = Float(0)
        var yy_r = Float(0)
        yy_r = xx_r * k_r + b_r
        yy_r = xx_r * k4 + b4
        xx_r = (b4 - b_r) / (k_r - k4)
        yy_r = xx_r * k4 + b4
        let y2_r = (yy_r - y) * fabsf(yy_r - y)
        let x2_r = (xx_r - x) * fabsf(xx_r - x)
        let dis_r = sqrt(fabsf(y2_r + x2_r))
        print(y2_r,x2_r,dis_r)
        
        if fabsf(y2_l + y2_r) == fabsf(y2_l) + fabsf(y2_r) {
            opx = Float(1)
            if y2_l < 0 && y2_r < 0 {
                opx = Float(0)
                mulx = -Float(1)
                typex = -Float(1)
            }
            if y2_l > 0 && y2_r > 0 {
                typex = Float(1)
            }
        }
        
        let leftx = (topViewPoints[0] as! CGPoint).x
        let rightx = (topViewPoints[1] as! CGPoint).x
        let left_right = rightx - leftx
        var plusX = left_right * CGFloat(dis_l/(dis_r + dis_l) * mulx + opx)
        if typex == -1 {
            plusX = left_right * CGFloat(-dis_l/dis_r)
        }
        if typex == 0 {
            plusX = left_right * CGFloat(dis_l/(dis_r + dis_l))
        }
        if typex == 1 {
            plusX = left_right * CGFloat(dis_r/(dis_l - dis_r))
        }
        
        let topy = (topViewPoints[0] as! CGPoint).y
        let bottomy = (topViewPoints[2] as! CGPoint).y
        let top_bottom = topy - bottomy
        var plusY = top_bottom * CGFloat(dis/(dis_b + dis) * muly + opy)
        if typey == -1 {
            plusY = top_bottom * CGFloat(-dis/dis_b)
        }
        if typey == 0 {
            plusY = top_bottom * CGFloat(dis/(dis_b + dis))
        }
        if typey == 1 {
            plusY = top_bottom * CGFloat(dis/(dis - dis_b))
        }
        
        let p = CGPoint(x: leftx + plusX, y: 200 - topy + plusY)
        return p
    }
    
}
