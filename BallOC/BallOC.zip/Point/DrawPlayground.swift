//
//  DrawPlayground.swift
//  Ball
//
//  Created by gwh on 2019/12/6.
//  Copyright © 2019 gwh. All rights reserved.
//

import UIKit

class DrawPlayground: UIView {

    var topLeft:CGPoint = CGPoint(x: 0, y: 0)
    var topRight:CGPoint = CGPoint(x: 0, y: 0)
    var bottomLeft:CGPoint = CGPoint(x: 0, y: 0)
    var bottomRight:CGPoint = CGPoint(x: 0, y: 0)
    
    var add:CGPoint = CGPoint(x: 0, y: 0)
    var addList:NSMutableArray = NSMutableArray.init()

    func setPoints(topLeft:CGPoint, topRight:CGPoint, bottomLeft:CGPoint, bottomRight:CGPoint) -> Void {
        
        self.topLeft = topLeft
        self.topRight = topRight
        self.bottomLeft = bottomLeft
        self.bottomRight = bottomRight
        
    }
    
    func addPoint(point:CGPoint) -> Void {
        self.addList.add(point)
        self.add = point
//        self.draw(self.frame)
        self.setNeedsDisplay()
    }
    
    override func draw(_ rect: CGRect) {
        
        UIColor.green.setFill()
        UIRectFill(CGRect(x: topLeft.x, y: topLeft.y, width: 5, height: 5))
        
        UIColor.green.setFill()
        UIRectFill(CGRect(x: topRight.x, y: topRight.y, width: 5, height: 5))
        
        UIColor.green.setFill()
        UIRectFill(CGRect(x: bottomLeft.x, y: bottomLeft.y, width: 5, height: 5))
        
        UIColor.green.setFill()
        UIRectFill(CGRect(x: bottomRight.x, y: bottomRight.y, width: 5, height: 5))
        
        for point in addList {

            UIColor.red.setFill()
            UIRectFill(CGRect(x: (point as! CGPoint).x, y: (point as! CGPoint).y, width: 5, height: 5))
        }
    }
    
}

