//
//  DrawTopView.swift
//  Ball
//
//  Created by gwh on 2019/12/6.
//  Copyright © 2019 gwh. All rights reserved.
//

import UIKit

class DrawTopCourtView: UIView {
    
//    var topLeft:CGPoint = CGPoint(x: 0, y: 0)
//    var topRight:CGPoint = CGPoint(x: 0, y: 0)
//    var bottomLeft:CGPoint = CGPoint(x: 0, y: 0)
//    var bottomRight:CGPoint = CGPoint(x: 0, y: 0)
    
//    var add:CGPoint = CGPoint(x: 0, y: 0)
    var addList:NSMutableArray = NSMutableArray.init()
    
    var fixPointsPoint:NSArray!
    
    var fixPoints:NSMutableArray!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        fixPoints = ccs.mutArray()
        for _ in 0..<4 {
            let view = ccs.view()!
            view.size = CGSize(width: 5, height: 5)
            view.layer.cornerRadius = 2.5
            view.backgroundColor = UIColor.green
            self.addSubview(view)
            fixPoints.add(view)
        }
        
        self.backgroundColor = COLOR_CLEAR()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
//    func setPoints(topLeft:CGPoint, topRight:CGPoint, bottomLeft:CGPoint, bottomRight:CGPoint) -> Void {
//
//        self.topLeft = topLeft
//        self.topRight = topRight
//        self.bottomLeft = bottomLeft
//        self.bottomRight = bottomRight
//
//    }
    
    func addPoint(point: CGPoint) -> Void {
        addList.add(point)
//        self.add = point
//        self.draw(self.frame)
        self.setNeedsDisplay()
    }
    
    func highlight(index: Int) {
        let view:CC_View = fixPoints![index] as! CC_View
        let center:CGPoint = view.center
        UIView.animate(withDuration: 0.2, animations: {
            view.size = CGSize(width: 30, height: 30)
            view.layer.cornerRadius = 15
            view.center = center
        }) { (finish) in
            UIView.animate(withDuration: 0.3, animations: {
                view.size = CGSize(width: 5, height: 5)
                view.layer.cornerRadius = 2.5
                view.center = center
            }) { (finish) in
                
            }
        }
    }
    
    override func draw(_ rect: CGRect) {
        
        for i in 0..<4 {

            let view:CC_View = fixPoints![i] as! CC_View
            view.center = fixPointsPoint![i] as! CGPoint
//            UIColor.green.setFill()
//            UIRectFill(CGRect(x: (fixPointsPoint[i] as! CGPoint).x, y: (fixPointsPoint[i] as! CGPoint).y, width: 5, height: 5))
        }
        
//        UIColor.green.setFill()
//        UIRectFill(CGRect(x: topRight.x, y: topRight.y, width: 5, height: 5))
//
//        UIColor.green.setFill()
//        UIRectFill(CGRect(x: bottomLeft.x, y: bottomLeft.y, width: 5, height: 5))
//
//        UIColor.green.setFill()
//        UIRectFill(CGRect(x: bottomRight.x, y: bottomRight.y, width: 5, height: 5))
        
        for point in addList {

            UIColor.red.setFill()
            UIRectFill(CGRect(x: (point as! CGPoint).x, y: (point as! CGPoint).y, width: 5, height: 5))
        }
    }
    
}
