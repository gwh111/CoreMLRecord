//
//  ArrowLayer.swift
//  BallOC
//
//  Created by gwh on 2019/12/25.
//  Copyright © 2019 gwh. All rights reserved.
//

import Foundation

class ArrowLayer: CAShapeLayer {

    override func draw(in ctx: CGContext) {

//        let linePath:UIBezierPath = UIBezierPath.init()
//        linePath.move(to: CGPoint(x: 0, y: 0))
//        // 其他点
//        linePath.addLine(to: CGPoint.init(x: 20, y: 0))
//        linePath.addLine(to: CGPoint.init(x: 10, y: 20))
//        linePath.close()
        
        ctx.setFillColor(UIColor.orange.cgColor)
        ctx.move(to: CGPoint(x: 0, y: 0))//起点
        ctx.addLine(to: CGPoint(x: 20, y: 0))//第二个点
        ctx.addLine(to: CGPoint(x: 10, y: 20))//第三个点
        ctx.closePath()
        ctx.fillPath()

        let delta = 0
        ctx.setLineWidth(1)
        ctx.setStrokeColor(UIColor.white.cgColor)
        ctx.move(to: CGPoint(x: 0 + delta, y: 0))//起点
        ctx.addLine(to: CGPoint(x: 20 + delta, y: 0))//第二个点
        ctx.addLine(to: CGPoint(x: 10 + delta, y: 20))//第三个点
        ctx.closePath()
        ctx.strokePath()
        
        
    }
}
