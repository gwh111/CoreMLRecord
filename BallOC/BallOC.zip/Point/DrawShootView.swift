//
//  DrawShootView.swift
//  Ball
//
//  Created by gwh on 2019/12/9.
//  Copyright © 2019 gwh. All rights reserved.
//

import UIKit

class DrawShootView: UIView {
    
    var fromList:NSMutableArray = NSMutableArray.init()
    var topList:NSMutableArray = NSMutableArray.init()
    
    override func draw(_ rect: CGRect) {
        
//        let x = 100
//        let y = 100
//
//        let pathQuad = UIBezierPath()
//        pathQuad.move(to: CGPoint(x: 200, y: y + 50))
//        pathQuad.addQuadCurve(to: CGPoint(x: 440, y: y), controlPoint: CGPoint(x: 350, y: y - 150))
//        UIColor.cyan.setStroke()
//        pathQuad.stroke()
    
        for count in 0..<fromList.count {
            
            let fromPoint:CGPoint = fromList[count] as! CGPoint
            let topPoint:CGPoint = topList[count] as! CGPoint
            
            var plusx = 80 as CGFloat
            if fromPoint.x > topPoint.x {
                plusx = -80
            }
            
            let pathQuad = UIBezierPath()
            pathQuad.move(to: fromPoint)
            pathQuad.addQuadCurve(to: CGPoint(x: topPoint.x + plusx, y: topPoint.y + 50), controlPoint: CGPoint(x: topPoint.x, y: topPoint.y - 60))
            UIColor.cyan.setStroke()
            pathQuad.stroke()
        }
    }
    
    func addShoot(fromPoint:CGPoint, topPoint:CGPoint) -> Void {
        
        self.fromList.add(fromPoint)
        self.topList.add(topPoint)
        
        self.setNeedsDisplay()
    }

}
