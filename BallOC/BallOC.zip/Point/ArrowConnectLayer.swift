//
//  ArrowConnectLayer.swift
//  BallOC
//
//  Created by gwh on 2019/12/25.
//  Copyright © 2019 gwh. All rights reserved.
//

import Foundation

class ArrowConnectLayer: CAShapeLayer {
    
    var points:NSMutableArray = NSMutableArray.init()

    override func draw(in ctx: CGContext) {
        
        if points.count < 4 {
            return
        }
        ctx.setFillColor(RGBA(255, 255, 0, 0.8).cgColor)
        ctx.move(to: points[0] as! CGPoint)
        ctx.addLine(to: points[1] as! CGPoint)
        ctx.addLine(to: points[2] as! CGPoint)
        ctx.addLine(to: points[3] as! CGPoint)
        ctx.closePath()
        ctx.fillPath()
        
    }
    
}
