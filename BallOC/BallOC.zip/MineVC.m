//
//  MineVC.m
//  BallOC
//
//  Created by gwh on 2019/12/10.
//  Copyright © 2019 gwh. All rights reserved.
//

#import "MineVC.h"

@interface MineVC ()

@end

@implementation MineVC

- (void)cc_viewWillLoad {
   
   self.cc_title = @"我的";
}

- (void)cc_viewDidLoad {
	 // Do any additional setup after loading the view.
    
    UIImage *image = IMAGE(@"mine");
    float height = WIDTH() * image.size.height / image.size.width;
    RGB(10, 101, 10);
    ccs.ImageView
    .cc_frame(0, 0, WIDTH(), height)
    .cc_image(image)
    .cc_addToView(self);
    
    [self cc_adaptUI];
}

@end
