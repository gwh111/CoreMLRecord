//
//  TabBarVC.m
//  BallOC
//
//  Created by gwh on 2019/12/10.
//  Copyright © 2019 gwh. All rights reserved.
//

#import "TabBarVC.h"

#import "HomeVC.h"
#import "SportVC.h"
#import "MineVC.h"

@interface TabBarVC ()

@end

@implementation TabBarVC

- (void)cc_viewWillLoad {
    self.view.backgroundColor = UIColor.whiteColor;
    // 纯图片 tabbar
    //    [self cc_initWithClasses:@[HomeVC.class,UIViewController.class]
    //                      images:@[@"tabbar_mine_high",@"tabbar_mine_high"]
    //              selectedImages:@[@"tabbar_mine_high",@"tabbar_mine_high"]];
    // 图片 + 文字 tabbar
    [self cc_initWithClasses:@[HomeVC.class,SportVC.class,HomeVC.class,MineVC.class]
                      titles:@[@"动态",@"运动",@"发现",@"我的"]
                      images:@[@"tab_home",@"tab_sport",@"tab_discovery",@"tab_mine"]
              selectedImages:@[@"tab_home_selected",@"tab_sport_selected",@"tab_discovery_selected",@"tab_mine_selected"]
                  titleColor:UIColor.darkGrayColor
          selectedTitleColor:UIColor.blackColor];

}

@end
