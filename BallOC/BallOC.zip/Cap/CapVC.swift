/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Contains the view controller for the Breakfast Finder.
*/

import UIKit
import AVFoundation
import Vision

import RealityKit
import ARKit

import Photos

class CapVC: CC_ViewController, AVCaptureVideoDataOutputSampleBufferDelegate {
    
    var bufferSize: CGSize = .zero
    var rootLayer: CALayer! = nil
    
    var scoreLabel: CC_Label! = nil
    
    var detectCount = 30
    var shootCount = 0
    
    @IBOutlet private var previewView: UIView!
    private let session = AVCaptureSession()
    private let recordSession = AVCaptureSession()
    
    private var previewLayer: AVCaptureVideoPreviewLayer! = nil
    private let videoDataOutput = AVCaptureVideoDataOutput()
    
    //  将捕获到的视频输出到文件
    let recordOutput = AVCaptureMovieFileOutput()
    
    private let videoDataOutputQueue = DispatchQueue(label: "VideoDataOutput", qos: .userInitiated, attributes: [], autoreleaseFrequency: .workItem)
    
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // to be implemented in the subclass
    }
    
    override func cc_viewDidLoad() {
        
        self.setupPreviewView()
        self.setupAVCapture()
        self.setupScore()
        
//        self.setupRecordCapture()
//        self.record()
//
//        ccs.delay(5) {
//            self.recordSession.stopRunning()
//        }
    }
    
    override func cc_viewWillAppear() {
        
    }
    
    override func cc_viewWillDisappear() {
        ccs.setDeviceOrientation(.portrait)
    }
    
    func setupRecordCapture() {
        var deviceInput: AVCaptureDeviceInput!
        
        // Select a video device, make an input
        let videoDevice = AVCaptureDevice.DiscoverySession(deviceTypes: [.builtInWideAngleCamera], mediaType: .video, position: .back).devices.first
        do {
            deviceInput = try AVCaptureDeviceInput(device: videoDevice!)
        } catch {
            print("Could not create video device input: \(error)")
            return
        }
        
        recordSession.beginConfiguration()
        recordSession.sessionPreset = .vga640x480 // Model image size is smaller.
        recordSession.addInput(deviceInput)
        recordSession.addOutput(recordOutput)
        
        recordSession.commitConfiguration()
    }
    
    func record() {
        
//        recordSession.startRunning()
        
        //  设置录像保存地址，在 Documents 目录下，名为 当前时间.mp4
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentDirectory = path[0] as String
        let filePath: String? = "\(documentDirectory)/\(Date()).mp4"
        let fileUrl: URL? = URL(fileURLWithPath: filePath!)
        //  启动视频编码输出
        recordOutput.startRecording(to: fileUrl!, recordingDelegate: self)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setupScore() {
        
        let height = UIScreen.main.bounds.size.height
        let width = UIScreen.main.bounds.size.width
        
        let backButton = CC_Button.init()
        backButton.setTitle("后退", for: .normal)
        backButton.frame = CGRect(x: 20, y: 20, width: 50, height: 50)
        backButton.layer.cornerRadius = 25
        backButton.backgroundColor = UIColor.init(red: 0, green: 0, blue: 0, alpha: 0.4)
        backButton.cc_addTappedOnceDelay(0.5) { (button) in
            ccs.popViewController();
        }
        self.view.addSubview(backButton)
        
        let cleanButton = CC_Button.init()
        cleanButton.setTitle("清零", for: .normal)
        cleanButton.frame = CGRect(x: width - 100, y: 20, width: 50, height: 50)
        cleanButton.layer.cornerRadius = 25
        cleanButton.backgroundColor = UIColor.init(red: 0, green: 0, blue: 0, alpha: 0.4)
        cleanButton.cc_addTappedOnceDelay(0.5) { (button) in
            self.shootCount = 0
            self.updateScore()
        }
        self.view.addSubview(cleanButton)
        
        let scoreView = CC_View.init()
        scoreView.size = CGSize(width: 300, height: 100)
        scoreView.center = CGPoint(x: width/2, y: height - 100)
        scoreView.layer.cornerRadius = 8
        scoreView.backgroundColor = UIColor.init(red: 0, green: 0, blue: 0, alpha: 0.4)
        self.view.addSubview(scoreView)
        
        scoreLabel = CC_Label.init()
        scoreLabel.size = CGSize(width: 200, height: 50)
        scoreLabel.center = CGPoint(x: scoreView.width/2, y: scoreView.height/2)
        scoreLabel.layer.cornerRadius = 4
        scoreLabel.textAlignment = .center
        scoreLabel.font = UIFont.systemFont(ofSize: 22)
        scoreLabel.textColor = UIColor.white
        scoreLabel.text = "Shoot:0|Goal:0"
        scoreView.addSubview(scoreLabel)
        
    }
    
    func updateScore() {
        
        scoreLabel.text = String(format: "Shoot:%d|Goal:0",shootCount)
    }
    
    func setupPreviewView() {
//        previewView?.removeFromSuperview()
        let height = UIScreen.main.bounds.size.height
        let width = UIScreen.main.bounds.size.width
        previewView = UIView.init(frame: CGRect(x: 0, y: 0, width: width, height: height))
        self.view.addSubview(previewView)
    }
    
    func setupAVCapture() {
        var deviceInput: AVCaptureDeviceInput!
        
        // Select a video device, make an input
        let videoDevice = AVCaptureDevice.DiscoverySession(deviceTypes: [.builtInWideAngleCamera], mediaType: .video, position: .back).devices.first
        do {
            deviceInput = try AVCaptureDeviceInput(device: videoDevice!)
        } catch {
            print("Could not create video device input: \(error)")
            return
        }
        
        session.beginConfiguration()
        session.sessionPreset = .vga640x480 // Model image size is smaller.
        
        // Add a video input
        guard session.canAddInput(deviceInput) else {
            print("Could not add video device input to the session")
            session.commitConfiguration()
            return
        }
        session.addInput(deviceInput)
        if session.canAddOutput(videoDataOutput) {
            session.addOutput(videoDataOutput)
            // Add a video data output
            videoDataOutput.alwaysDiscardsLateVideoFrames = true
            videoDataOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: Int(kCVPixelFormatType_420YpCbCr8BiPlanarFullRange)]
            videoDataOutput.setSampleBufferDelegate(self, queue: videoDataOutputQueue)
        } else {
            print("Could not add video data output to the session")
            session.commitConfiguration()
            return
        }
        if session.canAddOutput(recordOutput) {
            session.addOutput(recordOutput)
            NSLog("canAddOutput(recordOutput)")
        } else {
            NSLog("no canAddOutput(recordOutput)")
        }
        let captureConnection = videoDataOutput.connection(with: .video)
        captureConnection?.videoOrientation = .landscapeRight
        
        // Always process the frames
        captureConnection?.isEnabled = true
        do {
            try videoDevice!.lockForConfiguration()
            let dimensions = CMVideoFormatDescriptionGetDimensions((videoDevice?.activeFormat.formatDescription)!)
            bufferSize.width = CGFloat(dimensions.width)
            bufferSize.height = CGFloat(dimensions.height)
            videoDevice!.unlockForConfiguration()
        } catch {
            print(error)
        }
        session.commitConfiguration()
        previewLayer = AVCaptureVideoPreviewLayer(session: session)
        previewLayer.connection?.videoOrientation = .landscapeLeft
        previewLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
//        previewLayer.name = "previewLayer"
        rootLayer = previewView.layer
        previewLayer.frame = rootLayer.bounds
        rootLayer.addSublayer(previewLayer)
        
    }
    
    func startCaptureSession() {
        session.startRunning()
    }
    
    // Clean up capture setup
    func teardownAVCapture() {
        previewLayer.removeFromSuperlayer()
        previewLayer = nil
    }
    
    func captureOutput(_ captureOutput: AVCaptureOutput, didDrop didDropSampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        let buff = CMSampleBufferGetImageBuffer(didDropSampleBuffer)
        // print("frame dropped")
        
    }
    
    public func exifOrientationFromDeviceOrientation() -> CGImagePropertyOrientation {
//        let curDeviceOrientation = UIDevice.current.orientation
        
        let curDeviceOrientation = UIDevice.current.orientation
        let exifOrientation: CGImagePropertyOrientation
        
        switch curDeviceOrientation {
        case UIDeviceOrientation.portraitUpsideDown:  // Device oriented vertically, home button on the top
            exifOrientation = .left
        case UIDeviceOrientation.landscapeLeft:       // Device oriented horizontally, home button on the right
            exifOrientation = .upMirrored
        case UIDeviceOrientation.landscapeRight:      // Device oriented horizontally, home button on the left
            exifOrientation = .down
        case UIDeviceOrientation.portrait:            // Device oriented vertically, home button on the bottom
            exifOrientation = .up
        default:
            exifOrientation = .up
        }
        return exifOrientation
    }
}

// MARK: - AVCaptureFileOutputRecordingDelegate
extension CapVC: AVCaptureFileOutputRecordingDelegate {
    /// 开始录制
    func fileOutput(_ output: AVCaptureFileOutput, didStartRecordingTo fileURL: URL, from connections: [AVCaptureConnection]) {
        PHPhotoLibrary.shared()
    }
    
    /// 结束录制
    func fileOutput(_ output: AVCaptureFileOutput, didFinishRecordingTo outputFileURL: URL, from connections: [AVCaptureConnection], error: Error?) {
//            operatorView.getVideoUrl(videoUrl: outputFileURL)
        
        saveVideoToAlbum(videoUrl: outputFileURL)
    }
    
    /**
     将视频保存到本地
     
     - parameter videoUrl: 保存链接
     */
    private func saveVideoToAlbum(videoUrl: URL) {
        var info = ""
        PHPhotoLibrary.shared().performChanges({
            PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: videoUrl)
        }) { (success, error) in
            if success {
                info = "保存成功"
            } else {
                info = "保存失败，err = \(error.debugDescription)"
            }
            
            print(info)
        }
    }
}

