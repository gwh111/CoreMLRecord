//
//  RecordVC.m
//  BallOC
//
//  Created by gwh on 2019/12/10.
//  Copyright © 2019 gwh. All rights reserved.
//

#import "SportVC.h"
#import "BallOC-Swift.h"

@interface SportVC ()

@end

@implementation SportVC

- (void)cc_viewWillAppear {
    CCLOG(@"RecordVC cc_viewWillAppear");
    [ccs setDeviceOrientation:UIDeviceOrientationLandscapeRight];
    
    id vc = [ccs init:VisionObjectRecognitionViewController.class];
    [ccs pushViewController:vc];
}

- (void)cc_viewWillLoad {
   
    self.cc_title = @"运动";
}

- (void)cc_viewDidLoad {
	 // Do any additional setup after loading the view.
    
}

@end
