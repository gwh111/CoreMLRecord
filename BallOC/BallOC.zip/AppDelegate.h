//
//  AppDelegate.h
//  BallOC
//
//  Created by gwh on 2019/12/9.
//  Copyright 2019 gwh. All rights reserved.
//

#import "CC_AppDelegate.h"

@interface AppDelegate : CC_AppDelegate

@end


