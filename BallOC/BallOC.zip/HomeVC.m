//
//  ViewController.m
//  BallOC
//
//  Created by gwh on 2019/12/9.
//  Copyright 2019 gwh. All rights reserved.
//

#import "HomeVC.h"
#import "DetailVC.h"

@interface HomeVC ()

@end

@implementation HomeVC

- (void)cc_viewWillLoad {
  
    self.cc_title = @"首页";
//    self.cc_navigationBarHidden = YES;
}

- (void)cc_viewDidLoad {
	 // Do any additional setup after loading the view.
    
    UIImage *image = IMAGE(@"home");
    float height = WIDTH() * image.size.height / image.size.width;
    
    CC_ImageView *imageView =
    ccs.ImageView
    .cc_frame(0, 0, WIDTH(), height)
    .cc_image(image)
    .cc_addToView(self);
    [imageView cc_tappedInterval:.1 withBlock:^(id  _Nonnull view) {
        
    }];
    
    CC_Button *qb = ccs.Button
    .cc_frame(0, RH(10), WIDTH(), RH(600))
    .cc_addToView(self);
    [qb cc_addTappedOnceDelay:.5 withBlock:^(CC_Button *btn) {
        
        DetailVC *vc = [ccs init:DetailVC.class];
        vc.videoIndex = 0;
        [ccs pushViewController:vc];
    }];
    
    CC_Button *gby = ccs.Button
    .cc_frame(0, RH(600), WIDTH(), RH(600))
    .cc_addToView(self);
    [gby cc_addTappedOnceDelay:.5 withBlock:^(CC_Button *btn) {
        
        DetailVC *vc = [ccs init:DetailVC.class];
        vc.videoIndex = 1;
        [ccs pushViewController:vc];
    }];
    
    CC_Button *strange = ccs.Button
    .cc_frame(0, RH(1200), WIDTH(), RH(600))
    .cc_addToView(self);
    [strange cc_addTappedOnceDelay:.5 withBlock:^(CC_Button *btn) {
        
        DetailVC *vc = [ccs init:DetailVC.class];
        vc.videoIndex = 2;
        [ccs pushViewController:vc];
    }];
    
    [self cc_adaptUI];
    
//    [self getRGBsArrFromImage:IMAGE(@"icon")];
}

- (NSArray *)getRGBsArrFromImage:(UIImage *)image {
    //1.get the image into your data buffer
    CGImageRef imageRef = [image CGImage];
    NSUInteger imageW = CGImageGetWidth(imageRef);
    NSUInteger imageH = CGImageGetHeight(imageRef);
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    NSUInteger bytesPerPixel = 4;//一个像素四个分量，即ARGB
    NSUInteger bytesPerRow = bytesPerPixel * imageW;
    unsigned char *rawData = (unsigned char *)calloc(imageH*imageW*bytesPerPixel, sizeof(unsigned char));
    NSUInteger bitsPerComponent = 8;//每个分量8个字节
    /*
     参数1：数据源
     参数2：图片宽
     参数3：图片高
     参数4：表示每一个像素点，每一个分量大小
     在我们图像学中，像素点：ARGB组成 每一个表示一个分量（例如，A，R，G，B）
     在我们计算机图像学中每一个分量的大小是8个字节
     参数5：每一行大小（其实图片是由像素数组组成的）
     如何计算每一行的大小，所占用的内存
     首先计算每一个像素点大小（我们取最大值）： ARGB是4个分量 = 每个分量8个字节 * 4
     参数6:颜色空间
     参数7:是否需要透明度
     */
    CGContextRef context = CGBitmapContextCreate(rawData, imageW, imageH, bitsPerComponent, bytesPerRow, colorSpace, kCGImageAlphaPremultipliedLast | kCGBitmapByteOrder32Big);
    CGContextDrawImage(context, CGRectMake(0, 0, imageW, imageH), imageRef);
    
    //2.Now your rawData contains the image data int the RGBA8888 pixel format
    NSUInteger blackPixel = 0;
    NSMutableArray *pixelsArr = [NSMutableArray array];
//    for (int y = 0; y < imageH; y++) {
//        for (int x = 0; x < imageW; x++) {
//            NSUInteger byteIndex = bytesPerRow*y + bytesPerPixel*x;
//            //rawData一维数组存储方式RGBA(第一个像素)RGBA(第二个像素)
//            NSUInteger red = rawData[byteIndex];
//            NSUInteger green = rawData[byteIndex+1];
//            NSUInteger blue = rawData[byteIndex+2];
//            NSUInteger alpha = rawData[byteIndex+3];
//            XPixelItem *pixelItem = [[XPixelItem alloc] init];
//            pixelItem.color = [UIColor colorWithRed:red/255.0 green:green/255.0 blue:blue/255.0 alpha:alpha/255.0];
//            pixelItem.location = CGPointMake(x, y);
//            [pixelsArr addObject:pixelItem];
//            if  (red+green+blue == 0 && (alpha/255.0 >= 0.5)){//计算黑色部分所占比例
//                blackPixel++;
//            }
//        }
//    }
    NSLog(@"黑色所占的面积--%f,%lu",blackPixel*1.0/(imageW*imageH),(unsigned long)pixelsArr.count);
    imageRef = CGBitmapContextCreateImage(context);
    CGContextRelease(context);
    CGColorSpaceRelease(colorSpace);
    free(rawData);
    return pixelsArr;
}

@end
