//
//  DetailVC.m
//  BallOC
//
//  Created by gwh on 2019/12/11.
//  Copyright © 2019 gwh. All rights reserved.
//

#import "DetailVC.h"
#import "BallOC-Swift.h"
#import <AVKit/AVKit.h>

@interface DetailVC ()

@property (nonatomic, strong) NSString *videoUrl;
@property (nonatomic, strong) AVPlayerViewController *playerVC;

@end

@implementation DetailVC

- (void)cc_viewWillLoad {
   
   self.cc_title = @"详情";
}

- (void)cc_viewDidLoad {
	 // Do any additional setup after loading the view.
    
    UIImage *image = IMAGE(@"detail");
    float height = WIDTH() * image.size.height / image.size.width;
    
    CC_ImageView *imageView =
    ccs.ImageView
    .cc_frame(0, 0, WIDTH(), height)
    .cc_image(image)
    .cc_addToView(self);
    [imageView cc_tappedInterval:.1 withBlock:^(id  _Nonnull view) {

        PointVC *vc = [ccs init:PointVC.class];
        [ccs pushViewController:vc];
    }];
    
    [self cc_adaptUI];
    
    [self addVideo];
}

- (void)addVideo {
    
    self.videoUrl = @"http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4";
        
    NSArray *names = @[@"video/VID_20191212_161120(2).mp4",@"video/20191109_085247(1).mp4",@"video/VID_20191212_161606(2).mp4"];
    NSString *filePath = [[NSBundle mainBundle] pathForResource:names[_videoIndex] ofType:nil];
    self.videoUrl = filePath;
    /*
     因为是 http 的链接，所以要去 info.plist里面设置
     App Transport Security Settings
     Allow Arbitrary Loads  = YES
     */
    self.playerVC = [[AVPlayerViewController alloc] init];
    self.playerVC.player = [AVPlayer playerWithURL:[self.videoUrl hasPrefix:@"http"] ? [NSURL URLWithString:self.videoUrl]:[NSURL fileURLWithPath:self.videoUrl]];
    self.playerVC.view.frame = CGRectMake(RH(10), RH(70), WIDTH() - RH(20), RH(210));
    self.playerVC.showsPlaybackControls = YES;
//self.playerVC.entersFullScreenWhenPlaybackBegins = YES;//开启这个播放的时候支持（全屏）横竖屏哦
//self.playerVC.exitsFullScreenWhenPlaybackEnds = YES;//开启这个所有 item 播放完毕可以退出全屏
    [self.cc_displayView addSubview:self.playerVC.view];
    
    if (self.playerVC.readyForDisplay) {
        [self.playerVC.player play];
    }
}

- (void)cc_dealloc {
    
}

@end
